package ru.itpark;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorServiceTest {

    @org.junit.jupiter.api.Test
    void calcDeposit()
    {
        CalculatorService service = new CalculatorService();
        int sum = (int) service.calcDeposit(99000,1,8);
        System.out.println(sum);
        //assertEquals(108000, sum);

    }
}